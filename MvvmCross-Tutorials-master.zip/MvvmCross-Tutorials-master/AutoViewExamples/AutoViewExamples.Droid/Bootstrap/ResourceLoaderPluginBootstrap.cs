using Cirrious.CrossCore.Plugins;

namespace AutoViewExamples.Droid.Bootstrap
{
    public class ResourceLoaderPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.ResourceLoader.PluginLoader>
    {
    }
}