using Cirrious.CrossCore.Plugins;

namespace AutoViewExamples.Touch.Bootstrap
{
    public class JsonPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.Json.PluginLoader>
    {
    }
}