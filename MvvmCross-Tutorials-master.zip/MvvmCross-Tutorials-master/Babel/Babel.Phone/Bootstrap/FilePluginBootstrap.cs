using Cirrious.CrossCore.Plugins;

namespace Babel.Phone.Bootstrap
{
    public class FilePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.File.PluginLoader>
    {
    }
}