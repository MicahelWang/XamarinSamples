using Cirrious.CrossCore.Plugins;

namespace Babel.Phone.Bootstrap
{
    public class JsonLocalisationPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.JsonLocalisation.PluginLoader>
    {
    }
}