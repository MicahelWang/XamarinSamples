﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cirrious.CrossCore.WindowsPhone.Converters;
using Cirrious.MvvmCross.Localization;

namespace Babel.Phone.Converters
{
    public class NativeLanguageConverter : MvxNativeValueConverter<MvxLanguageConverter>
    {
    }
}
