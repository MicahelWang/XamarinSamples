﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Navigation;
using Cirrious.MvvmCross.WindowsPhone.Views;
using Microsoft.Phone.Controls;
using Microsoft.Phone.Shell;

namespace Babel.Phone.Views
{
    public partial class SecondView : MvxPhonePage
    {
        public SecondView()
        {
            InitializeComponent();
        }
    }
}