using Cirrious.MvvmCross.WindowsPhone.Views;

namespace Babel.Phone.Views
{
    public partial class FirstView : MvxPhonePage
    {
        public FirstView()
        {
            InitializeComponent();
        }
    }
}