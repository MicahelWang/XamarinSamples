using Cirrious.CrossCore.Plugins;

namespace Babel.Touch.Bootstrap
{
    public class JsonLocalisationPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.JsonLocalisation.PluginLoader>
    {
    }
}