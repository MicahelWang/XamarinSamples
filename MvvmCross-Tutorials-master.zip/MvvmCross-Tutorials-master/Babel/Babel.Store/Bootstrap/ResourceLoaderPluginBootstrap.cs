using Cirrious.CrossCore.Plugins;

namespace Babel.Store.Bootstrap
{
    public class ResourceLoaderPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.ResourceLoader.PluginLoader>
    {
    }
}