﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cirrious.CrossCore.WindowsStore.Converters;
using Cirrious.MvvmCross.Localization;

namespace Babel.Store.Converters
{
    public class NativeLanguageConverter : MvxNativeValueConverter<MvxLanguageConverter>
    {
    }
}
