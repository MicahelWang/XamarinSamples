using Cirrious.MvvmCross.ViewModels;

namespace Babel.Core.ViewModels
{
    public class SecondViewModel
        : BaseViewModel
    {
    }
}