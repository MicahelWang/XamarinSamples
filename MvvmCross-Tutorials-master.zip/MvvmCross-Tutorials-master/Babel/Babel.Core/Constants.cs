namespace Babel.Core
{
    public static class Constants
    {
        public const string RootFolderForResources = "BabelResources/Text";
        public const string GeneralNamespace = "Babel";
    }
}