using Cirrious.CrossCore.Plugins;

namespace Babel.Droid.Bootstrap
{
    public class FilePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.File.PluginLoader>
    {
    }
}