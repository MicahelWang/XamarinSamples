using Cirrious.CrossCore.Plugins;

namespace Babel.Droid.Bootstrap
{
    public class JsonLocalisationPluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.JsonLocalisation.PluginLoader>
    {
    }
}