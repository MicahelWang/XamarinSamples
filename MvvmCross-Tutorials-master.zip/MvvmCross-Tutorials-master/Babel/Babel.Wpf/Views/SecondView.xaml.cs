﻿using Cirrious.MvvmCross.Wpf.Views;

namespace Babel.Wpf.Views
{
    /// <summary>
    /// Interaction logic for SecondView.xaml
    /// </summary>
    public partial class SecondView : MvxWpfView
    {
        public SecondView()
        {
            InitializeComponent();
        }
    }
}
