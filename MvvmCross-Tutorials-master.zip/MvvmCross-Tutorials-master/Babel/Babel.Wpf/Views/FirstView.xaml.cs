using Cirrious.MvvmCross.Wpf.Views;

namespace Babel.Wpf.Views
{
    public partial class FirstView : MvxWpfView
    {
        public FirstView()
        {
            this.InitializeComponent();
        }
    }
}
