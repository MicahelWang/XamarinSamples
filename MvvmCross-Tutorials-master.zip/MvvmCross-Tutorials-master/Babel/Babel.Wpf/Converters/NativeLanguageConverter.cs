﻿using Cirrious.MvvmCross.Localization;
using Cirrious.MvvmCross.Wpf.Converters;

namespace Babel.Wpf.Converters
{
    public class NativeLanguageConverter : MvxNativeValueConverter<MvxLanguageConverter>
    {
    }
}
