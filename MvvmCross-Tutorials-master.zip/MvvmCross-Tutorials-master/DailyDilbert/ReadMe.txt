Update - october 2013 - Sadly Dilbert are no longer supplying images in their feeds:

"Due to changes with our feeds, we are now making this RSS feed a link to Dilbert.com."

:(