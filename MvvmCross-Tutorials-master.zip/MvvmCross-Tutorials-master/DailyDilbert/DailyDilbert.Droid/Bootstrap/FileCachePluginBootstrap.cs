using Cirrious.CrossCore.Plugins;

namespace Bootstrap
{
    public class FileCachePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.File.PluginLoader>
    {
    }
}