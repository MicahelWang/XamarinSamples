using Cirrious.CrossCore.Plugins;

namespace DailyDilbert.Droid.Bootstrap
{
    public class FilePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.File.PluginLoader>
    {
    }
}