using Cirrious.CrossCore.Plugins;

namespace DailyDilbert.Droid.Bootstrap
{
    public class DownloadCachePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Plugins.DownloadCache.PluginLoader>
    {
    }
}