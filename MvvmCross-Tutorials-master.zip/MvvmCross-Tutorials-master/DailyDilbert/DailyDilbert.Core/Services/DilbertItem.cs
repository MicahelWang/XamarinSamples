﻿namespace DailyDilbert.Core
{
    public class DilbertItem
    {
        public string Title { get; set; }
        public string StripUrl { get; set; }
    }
}
