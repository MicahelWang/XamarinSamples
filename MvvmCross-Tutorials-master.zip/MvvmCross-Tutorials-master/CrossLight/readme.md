## Cross Light

MvvmCross v3 - Hot Tuna - allows:

- people to use MvvmCross plugins without using MvvmCross
- people to use MvvmCross data-binding without using MvvmCross

This repo contains some examples of how to do that.

For some more information, see:

- https://github.com/slodge/mvvmcross
- http://slodge.blogspot.com/